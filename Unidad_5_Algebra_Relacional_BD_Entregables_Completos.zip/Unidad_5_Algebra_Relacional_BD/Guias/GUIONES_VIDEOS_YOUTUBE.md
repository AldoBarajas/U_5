# Guiones de grabación | Unidad 5 - Álgebra relacional

Los dos videos deben publicarse **públicos en el mismo canal de YouTube** con pantalla y cámara web en la **esquina inferior derecha**. Puedes capturarlos con OBS Studio. No se han grabado ni publicado los videos.

## Video 1 | Tarea 5.1 - operadores fundamentales y extendidos (5 a 7 minutos)

**0:00-0:30 — Presentación**

> En este video explico el álgebra relacional como lenguaje formal para obtener información de nuestra biblioteca escolar. Voy a usar el mapa conceptual y a diferenciar operadores unarios, binarios y extendidos.

**0:30-1:40 — Operadores unarios**

Muestra el bloque izquierdo del mapa. Presenta σ (selección: filtra filas), π (proyección: elige columnas y elimina duplicados), ρ (renombramiento). Explica `π_isbn,titulo(σ_anio_publicacion≥2020(Libro))`.

**1:40-3:40 — Operadores binarios**

Describe ×, ∪, ∩, −, ÷ y ⋈. Explica que UNION, INTERSECT, EXCEPT requieren compatibilidad de esquema. Da ejemplos con colecciones Ciencia/Literatura y muestra la pregunta universal de la división.

**3:40-5:20 — Operadores extendidos**

Explica proyección calculada, agrupación con COUNT y reuniones externas left/right/full. Señala que NULL aparece cuando no existe una correspondencia y que un LEFT JOIN sirve para mostrar autores sin libros.

**5:20-6:20 — Conclusión**

Relaciona los símbolos con SQL Server: WHERE, SELECT DISTINCT, CROSS JOIN, JOIN, UNION, INTERSECT, EXCEPT, GROUP BY y OUTER JOIN.

## Video 2 | Tarea 5.2 - catálogo y tres consultas complejas (7 a 10 minutos)

**0:00-0:35 — Contexto**

> Continuamos la biblioteca de las unidades anteriores. El catálogo resuelve 16 necesidades de información y cada consulta se descompone en relaciones intermedias antes de llevarse a SQL Server.

**0:35-1:15 — Estructura de las tablas**

Muestra `schema_sqlserver_unidad3.sql` o el esquema en SSMS; ubica Libro, Colección, LibroColeccion, Ejemplar, Préstamo, Persona y Autor. Distingue llaves primarias y foráneas.

**1:15-3:20 — Q08 (división)**

Explica las relaciones S (libro-colección) y T (colecciones exigidas). Escribe `S ÷ T` y explica la regla "para cada colección de T existe una fila asociada en S". Muestra el NOT EXISTS doble y el ejemplo donde `Proyecto final` aparece en Ciencia y Literatura.

**3:20-5:30 — Q10 (joins anidados)**

Explica la selección de préstamos activos, el join con Persona, Ejemplar y Libro, y la proyección final. Revisa cómo se conecta `id_persona`, `id_ejemplar` e `isbn`.

**5:30-7:30 — Q16 (selección, proyección y joins múltiples)**

Aplica los filtros: colección Ciencia, autor Ada Nieto y publicación desde 2020. Muestra las relaciones intermedias y el SELECT en SQL Server. Señala que un libro con varios autores no debe aparecer duplicado.

**7:30-8:40 — Prueba y limitaciones**

Ejecuta F5 en SSMS si tienes la base lista. Muestra pestaña Resultados/Mensajes y captura evidencia real. Si todavía no está listo SQL Server, ejecuta `python Tarea_5_2/verificar_consultas.py`, aclara ante el docente que esta comprobación usa datos ficticios en SQLite y que no equivale a haber ejecutado el motor SQL Server.

**8:40-9:10 — Cierre**

Concluye: el álgebra relacional permite formular, explicar y validar consultas antes de programarlas.

## Evidencias que deben acompañar el video

- Grabación de pantalla completa o ventana del programa, cursor visible.
- Webcam superpuesta en la esquina inferior derecha sin tapar expresiones.
- Audio con explicación oral real, no solamente diapositivas.
- Repositorio público de GitHub visible brevemente.
- Enlaces de ambos videos públicos adjuntos en Teams desde **tu mismo canal**.
