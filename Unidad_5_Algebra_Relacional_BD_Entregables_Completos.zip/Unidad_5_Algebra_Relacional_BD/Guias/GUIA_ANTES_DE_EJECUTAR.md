# Guía de ejecución en SQL Server Management Studio (SSMS)

**ATENCIÓN:** los archivos de esta Unidad 5 ya usan **T-SQL para SQL Server**, no PostgreSQL. Una base de datos y tablas deben existir antes de consultar.

## Si no has logrado crear la base de datos de la Unidad 3

1. Inicia **Microsoft SQL Server Management Studio** y comprueba la conexión a `(local)\SQLEXPRESS` (o tu instancia correspondiente).
2. Abre `Referencias_U3/schema_sqlserver_unidad3.sql` y ejecútalo **completo** con F5. No ejecutes solo las líneas `USE` o `CREATE TABLE` sin el resto.
3. Revisa la pestaña **Mensajes** del resultado, no únicamente la ventana **Lista de errores / IntelliSense**.
4. Comprueba con una nueva consulta:

```sql
SELECT DB_ID(N'BibliotecaEscolar_U3') AS id_base;
SELECT DB_NAME() AS base_actual;
```

5. La consulta siguiente debe listar las **12 tablas**:

```sql
USE [BibliotecaEscolar_U3];
SELECT t.name FROM sys.tables AS t
JOIN sys.schemas AS s ON s.schema_id=t.schema_id
WHERE s.name=N'biblioteca' ORDER BY t.name;
```

6. Si el script no se ejecutó bien, la tabla y el esquema no existen. No es suficiente borrar los subrayados de IntelliSense; lee los mensajes rojos de ejecución. Ctrl+Shift+R refresca IntelliSense, pero **no crea tablas**.

## Cargar datos ficticios de práctica (OPCIONAL)

- Hazlo únicamente en una base **sin registros**. `datos_demo_sqlserver.sql` tiene controles que cancelan la carga cuando detectan datos previos.
- Este archivo no borra objetos ni elimina registros. Inserta libros, autores, lectores, préstamos e incidencias completamente ficticios.
- Abre `Tarea_5_2/datos_demo_sqlserver.sql` en SSMS y pulsa F5.
- Si la base ya tiene registros, **NO ejecutes el script**. Puedes ejecutar `consultas_sqlserver.sql` directamente y comparar el resultado con tus propios datos.

## Ejecutar el catálogo

1. Abre `Tarea_5_2/consultas_sqlserver.sql`.
2. Ejecuta TODO con F5. Se obtienen 16 conjuntos de resultados, identificados por comentarios Q01 a Q16.
3. Selecciona cada bloque para ejecutarlo individualmente si quieres capturas por consulta. Mantén seleccionadas las líneas completas del SELECT, no solo una palabra.
4. Para evidencia de Teams, captura tres consultas avanzadas, recomendadas Q08 (división), Q10 (joins) y Q16 (selección con joins múltiples).

## Resultado de validación independiente

Para verificar cálculos aunque SQL Server aún no esté preparado:

```bash
python Tarea_5_2/verificar_consultas.py
```

Esto usa `sqlite3` de la biblioteca estándar; no requiere instalar paquetes. Imprime conteos, recrea `resultados_csv/` y actualiza `validacion_resultados.json`. Los resultados corresponden exclusivamente a datos ficticios.

## Errores frecuentes

- `Invalid object name 'biblioteca.libro'`: ejecuta primero el script de creación de tablas, revisa nombre de base y esquema.
- `Cannot open database 'BibliotecaEscolar_U3'`: la base no existe aún o no tienes permiso; revisa el script de Unidad 3.
- Resultado vacío: primero inserta datos demo en una base vacía o prueba con registros propios.
- Subrayado rojo sin mensaje real tras F5: IntelliSense puede tener la caché desactualizada.
- Si aparece un mensaje SQL Server concreto tras F5, conserva el número de error y la línea real para corregirlo; no asumas que todo es IntelliSense.

**Alcance honesto:** la ejecución sobre SQL Server Express no se realizó durante la preparación de este paquete.
